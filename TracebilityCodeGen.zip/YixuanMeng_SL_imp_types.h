/*
 * YixuanMeng_SL_imp_types.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "YixuanMeng_SL_imp".
 *
 * Model version              : 1.296
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri Dec 27 14:26:13 2019
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_YixuanMeng_SL_imp_types_h_
#define RTW_HEADER_YixuanMeng_SL_imp_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"

/* Parameters (default storage) */
typedef struct P_YixuanMeng_SL_imp_T_ P_YixuanMeng_SL_imp_T;

/* Forward declaration for rtModel */
typedef struct tag_RTM_YixuanMeng_SL_imp_T RT_MODEL_YixuanMeng_SL_imp_T;

#endif                               /* RTW_HEADER_YixuanMeng_SL_imp_types_h_ */
