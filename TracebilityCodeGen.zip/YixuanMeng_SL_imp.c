/*
 * YixuanMeng_SL_imp.c
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "YixuanMeng_SL_imp".
 *
 * Model version              : 1.296
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri Dec 27 14:26:13 2019
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "YixuanMeng_SL_imp.h"
#include "YixuanMeng_SL_imp_private.h"

/* Named constants for Chart: '<S1>/DDDPM' */
#define YixuanMeng_SL_im_IN_ActivePVARP ((uint8_T)1U)
#define YixuanMeng_SL_imp_IN_ActiveAVI ((uint8_T)1U)
#define YixuanMeng_SL_imp_IN_ActiveLRI ((uint8_T)1U)
#define YixuanMeng_SL_imp_IN_ActiveURI ((uint8_T)1U)
#define YixuanMeng_SL_imp_IN_ActiveVRP ((uint8_T)1U)
#define YixuanMeng_SL_imp_IN_AinPVARP  ((uint8_T)2U)
#define YixuanMeng_SL_imp_IN_CAVI      ((uint8_T)2U)
#define YixuanMeng_SL_imp_IN_IdleAVI   ((uint8_T)3U)
#define YixuanMeng_SL_imp_IN_IdleLRI   ((uint8_T)2U)
#define YixuanMeng_SL_imp_IN_IdlePVARP ((uint8_T)3U)
#define YixuanMeng_SL_imp_IN_IdleURI   ((uint8_T)2U)
#define YixuanMeng_SL_imp_IN_IdleVRP   ((uint8_T)2U)
#define YixuanMeng_SL_imp_IN_LRIVP     ((uint8_T)3U)
#define YixuanMeng_S_IN_NO_ACTIVE_CHILD ((uint8_T)0U)

/* Block states (default storage) */
DW_YixuanMeng_SL_imp_T YixuanMeng_SL_imp_DW;

/* Real-time model */
RT_MODEL_YixuanMeng_SL_imp_T YixuanMeng_SL_imp_M_;
RT_MODEL_YixuanMeng_SL_imp_T *const YixuanMeng_SL_imp_M = &YixuanMeng_SL_imp_M_;

/* Forward declaration for local functions */
static void YixuanMeng_SL_imp_DDDPM(void);

/* Function for Chart: '<S1>/DDDPM' */
static void YixuanMeng_SL_imp_DDDPM(void)
{
  uint16_T qY;
  if (YixuanMeng_SL_imp_DW.is_URI == YixuanMeng_SL_imp_IN_ActiveURI) {
    if (YixuanMeng_SL_imp_DW.VS || YixuanMeng_SL_imp_DW.VP1) {
      /* Constant: '<S1>/URI' */
      YixuanMeng_SL_imp_DW.tmpURI = YixuanMeng_SL_imp_P.URI_Value;
      YixuanMeng_SL_imp_DW.enterURI = false;
      YixuanMeng_SL_imp_DW.is_URI = YixuanMeng_SL_imp_IN_ActiveURI;
    } else if (YixuanMeng_SL_imp_DW.tmpURI > 0U) {
      qY = YixuanMeng_SL_imp_DW.tmpURI - 1U;
      if (qY > YixuanMeng_SL_imp_DW.tmpURI) {
        qY = 0U;
      }

      YixuanMeng_SL_imp_DW.tmpURI = qY;
      YixuanMeng_SL_imp_DW.is_URI = YixuanMeng_SL_imp_IN_ActiveURI;
    } else {
      if (YixuanMeng_SL_imp_DW.tmpURI <= 0U) {
        YixuanMeng_SL_imp_DW.enterURI = true;
        YixuanMeng_SL_imp_DW.is_URI = YixuanMeng_SL_imp_IN_IdleURI;
      }
    }
  } else {
    /* case IN_IdleURI: */
    if (YixuanMeng_SL_imp_DW.VP1 || YixuanMeng_SL_imp_DW.VS) {
      /* Constant: '<S1>/URI' */
      YixuanMeng_SL_imp_DW.tmpURI = YixuanMeng_SL_imp_P.URI_Value;
      YixuanMeng_SL_imp_DW.enterURI = false;
      YixuanMeng_SL_imp_DW.is_URI = YixuanMeng_SL_imp_IN_ActiveURI;
    }
  }

  switch (YixuanMeng_SL_imp_DW.is_LRI) {
   case YixuanMeng_SL_imp_IN_ActiveLRI:
    if (YixuanMeng_SL_imp_DW.APLRI == 1.0) {
      YixuanMeng_SL_imp_DW.APLRI++;
      YixuanMeng_SL_imp_DW.AP1 = false;
      qY = YixuanMeng_SL_imp_DW.tmpLRI - 1U;
      if (qY > YixuanMeng_SL_imp_DW.tmpLRI) {
        qY = 0U;
      }

      YixuanMeng_SL_imp_DW.tmpLRI = qY;
      YixuanMeng_SL_imp_DW.is_LRI = YixuanMeng_SL_imp_IN_ActiveLRI;
    } else if (YixuanMeng_SL_imp_DW.VS || YixuanMeng_SL_imp_DW.VP1) {
      /* Constant: '<S1>/LRI' */
      YixuanMeng_SL_imp_DW.tmpLRI = YixuanMeng_SL_imp_P.LRI_Value;
      YixuanMeng_SL_imp_DW.is_LRI = YixuanMeng_SL_imp_IN_IdleLRI;
    } else if (YixuanMeng_SL_imp_DW.tmpLRI > 0U) {
      qY = YixuanMeng_SL_imp_DW.tmpLRI - 1U;
      if (qY > YixuanMeng_SL_imp_DW.tmpLRI) {
        qY = 0U;
      }

      YixuanMeng_SL_imp_DW.tmpLRI = qY;
      YixuanMeng_SL_imp_DW.is_LRI = YixuanMeng_SL_imp_IN_ActiveLRI;
    } else {
      if (YixuanMeng_SL_imp_DW.tmpLRI <= 0U) {
        YixuanMeng_SL_imp_DW.VP1 = true;
        YixuanMeng_SL_imp_DW.is_LRI = YixuanMeng_SL_imp_IN_LRIVP;
      }
    }
    break;

   case YixuanMeng_SL_imp_IN_IdleLRI:
    if (YixuanMeng_SL_imp_DW.VS || YixuanMeng_SL_imp_DW.VP1) {
      /* Constant: '<S1>/LRI' */
      YixuanMeng_SL_imp_DW.tmpLRI = YixuanMeng_SL_imp_P.LRI_Value;
      YixuanMeng_SL_imp_DW.is_LRI = YixuanMeng_SL_imp_IN_IdleLRI;
    } else if (YixuanMeng_SL_imp_DW.AS) {
      qY = YixuanMeng_SL_imp_DW.tmpLRI - 1U;
      if (qY > YixuanMeng_SL_imp_DW.tmpLRI) {
        qY = 0U;
      }

      YixuanMeng_SL_imp_DW.tmpLRI = qY;
      YixuanMeng_SL_imp_DW.is_LRI = YixuanMeng_SL_imp_IN_ActiveLRI;
    } else if (YixuanMeng_SL_imp_DW.tmpLRI > YixuanMeng_SL_imp_P.AVI_Value) {
      qY = YixuanMeng_SL_imp_DW.tmpLRI - 1U;
      if (qY > YixuanMeng_SL_imp_DW.tmpLRI) {
        qY = 0U;
      }

      YixuanMeng_SL_imp_DW.tmpLRI = qY;
      YixuanMeng_SL_imp_DW.is_LRI = YixuanMeng_SL_imp_IN_IdleLRI;
    } else {
      if (YixuanMeng_SL_imp_DW.tmpLRI <= YixuanMeng_SL_imp_P.AVI_Value) {
        YixuanMeng_SL_imp_DW.APLRI = 1.0;
        YixuanMeng_SL_imp_DW.AP1 = true;
        qY = YixuanMeng_SL_imp_DW.tmpLRI - 1U;
        if (qY > YixuanMeng_SL_imp_DW.tmpLRI) {
          qY = 0U;
        }

        YixuanMeng_SL_imp_DW.tmpLRI = qY;
        YixuanMeng_SL_imp_DW.is_LRI = YixuanMeng_SL_imp_IN_ActiveLRI;
      }
    }
    break;

   default:
    /* case IN_LRIVP: */
    YixuanMeng_SL_imp_DW.VP1 = false;

    /* Constant: '<S1>/LRI' */
    YixuanMeng_SL_imp_DW.tmpLRI = YixuanMeng_SL_imp_P.LRI_Value;
    YixuanMeng_SL_imp_DW.is_LRI = YixuanMeng_SL_imp_IN_IdleLRI;
    break;
  }

  switch (YixuanMeng_SL_imp_DW.is_AVI) {
   case YixuanMeng_SL_imp_IN_ActiveAVI:
    if ((YixuanMeng_SL_imp_DW.tmpAVI <= 0U) && YixuanMeng_SL_imp_DW.enterURI) {
      YixuanMeng_SL_imp_DW.VP1 = true;
      YixuanMeng_SL_imp_DW.is_AVI = YixuanMeng_SL_imp_IN_CAVI;
    } else if (YixuanMeng_SL_imp_DW.VS || YixuanMeng_SL_imp_DW.VP1) {
      YixuanMeng_SL_imp_DW.is_AVI = YixuanMeng_SL_imp_IN_IdleAVI;
    } else {
      if (YixuanMeng_SL_imp_DW.tmpAVI > 0U) {
        qY = YixuanMeng_SL_imp_DW.tmpAVI - 1U;
        if (qY > YixuanMeng_SL_imp_DW.tmpAVI) {
          qY = 0U;
        }

        YixuanMeng_SL_imp_DW.tmpAVI = qY;
        YixuanMeng_SL_imp_DW.is_AVI = YixuanMeng_SL_imp_IN_ActiveAVI;
      }
    }
    break;

   case YixuanMeng_SL_imp_IN_CAVI:
    YixuanMeng_SL_imp_DW.VP1 = false;
    YixuanMeng_SL_imp_DW.is_AVI = YixuanMeng_SL_imp_IN_IdleAVI;
    break;

   default:
    /* case IN_IdleAVI: */
    if (YixuanMeng_SL_imp_DW.AS || YixuanMeng_SL_imp_DW.AP1) {
      /* Constant: '<S1>/AVI' */
      YixuanMeng_SL_imp_DW.tmpAVI = YixuanMeng_SL_imp_P.AVI_Value;
      YixuanMeng_SL_imp_DW.is_AVI = YixuanMeng_SL_imp_IN_ActiveAVI;
    }
    break;
  }

  switch (YixuanMeng_SL_imp_DW.is_VRP) {
   case YixuanMeng_SL_imp_IN_ActiveVRP:
    if (YixuanMeng_SL_imp_DW.tmpVRP > 0U) {
      qY = YixuanMeng_SL_imp_DW.tmpVRP - 1U;
      if (qY > YixuanMeng_SL_imp_DW.tmpVRP) {
        qY = 0U;
      }

      YixuanMeng_SL_imp_DW.tmpVRP = qY;
      YixuanMeng_SL_imp_DW.is_VRP = YixuanMeng_SL_imp_IN_ActiveVRP;
    } else {
      if (YixuanMeng_SL_imp_DW.tmpVRP <= 0U) {
        YixuanMeng_SL_imp_DW.is_VRP = YixuanMeng_SL_imp_IN_IdleVRP;
      }
    }
    break;

   case YixuanMeng_SL_imp_IN_IdleVRP:
    if (YixuanMeng_SL_imp_DW.VP1) {
      /* Constant: '<S1>/VRP' */
      YixuanMeng_SL_imp_DW.tmpVRP = YixuanMeng_SL_imp_P.VRP_Value;
      YixuanMeng_SL_imp_DW.is_VRP = YixuanMeng_SL_imp_IN_ActiveVRP;
    }
    break;

   default:
    /* Constant: '<S1>/VRP' */
    /* case IN_VRPVS: */
    YixuanMeng_SL_imp_DW.tmpVRP = YixuanMeng_SL_imp_P.VRP_Value;
    YixuanMeng_SL_imp_DW.VS = false;
    YixuanMeng_SL_imp_DW.is_VRP = YixuanMeng_SL_imp_IN_ActiveVRP;
    break;
  }

  switch (YixuanMeng_SL_imp_DW.is_PVARP) {
   case YixuanMeng_SL_im_IN_ActivePVARP:
    if (YixuanMeng_SL_imp_DW.tmpPVARP > 0U) {
      qY = YixuanMeng_SL_imp_DW.tmpPVARP - 1U;
      if (qY > YixuanMeng_SL_imp_DW.tmpPVARP) {
        qY = 0U;
      }

      YixuanMeng_SL_imp_DW.tmpPVARP = qY;
      YixuanMeng_SL_imp_DW.is_PVARP = YixuanMeng_SL_im_IN_ActivePVARP;
    } else {
      if (YixuanMeng_SL_imp_DW.tmpPVARP <= 0U) {
        YixuanMeng_SL_imp_DW.is_PVARP = YixuanMeng_SL_imp_IN_IdlePVARP;
      }
    }
    break;

   case YixuanMeng_SL_imp_IN_AinPVARP:
    YixuanMeng_SL_imp_DW.AS = false;
    YixuanMeng_SL_imp_DW.is_PVARP = YixuanMeng_SL_imp_IN_IdlePVARP;
    break;

   case YixuanMeng_SL_imp_IN_IdlePVARP:
    if (YixuanMeng_SL_imp_DW.VS || YixuanMeng_SL_imp_DW.VP1) {
      /* Constant: '<S1>/TPVARP' */
      YixuanMeng_SL_imp_DW.tmpPVARP = YixuanMeng_SL_imp_P.TPVARP_Value;
      YixuanMeng_SL_imp_DW.is_PVARP = YixuanMeng_SL_im_IN_ActivePVARP;
    }
    break;

   default:
    /* case IN_PVARPAR: */
    qY = YixuanMeng_SL_imp_DW.tmpPVARP - 1U;
    if (qY > YixuanMeng_SL_imp_DW.tmpPVARP) {
      qY = 0U;
    }

    YixuanMeng_SL_imp_DW.tmpPVARP = qY;
    YixuanMeng_SL_imp_DW.is_PVARP = YixuanMeng_SL_im_IN_ActivePVARP;
    break;
  }
}

/* Model step function */
void YixuanMeng_SL_imp_step(void)
{
  /* Chart: '<S1>/DDDPM' incorporates:
   *  Constant: '<S1>/AVI'
   *  Constant: '<S1>/LRI'
   *  Constant: '<S1>/TPVARP'
   *  Constant: '<S1>/URI'
   *  Constant: '<S1>/VRP'
   */
  if (YixuanMeng_SL_imp_DW.is_active_c1_YixuanMeng_SL_imp == 0U) {
    YixuanMeng_SL_imp_DW.is_active_c1_YixuanMeng_SL_imp = 1U;
    YixuanMeng_SL_imp_DW.tmpVRP = YixuanMeng_SL_imp_P.VRP_Value;
    YixuanMeng_SL_imp_DW.tmpPVARP = YixuanMeng_SL_imp_P.TPVARP_Value;
    YixuanMeng_SL_imp_DW.tmpAVI = YixuanMeng_SL_imp_P.AVI_Value;
    YixuanMeng_SL_imp_DW.tmpURI = YixuanMeng_SL_imp_P.URI_Value;
    YixuanMeng_SL_imp_DW.enterURI = true;
    YixuanMeng_SL_imp_DW.is_URI = YixuanMeng_SL_imp_IN_IdleURI;
    YixuanMeng_SL_imp_DW.tmpLRI = YixuanMeng_SL_imp_P.LRI_Value;
    YixuanMeng_SL_imp_DW.APLRI = 2.0;
    YixuanMeng_SL_imp_DW.AP1 = false;
    YixuanMeng_SL_imp_DW.is_LRI = YixuanMeng_SL_imp_IN_IdleLRI;
    YixuanMeng_SL_imp_DW.VP1 = false;
    YixuanMeng_SL_imp_DW.is_AVI = YixuanMeng_SL_imp_IN_IdleAVI;
    YixuanMeng_SL_imp_DW.VS = false;
    YixuanMeng_SL_imp_DW.is_VRP = YixuanMeng_SL_imp_IN_IdleVRP;
    YixuanMeng_SL_imp_DW.AS = false;
    YixuanMeng_SL_imp_DW.is_PVARP = YixuanMeng_SL_imp_IN_IdlePVARP;
  } else {
    YixuanMeng_SL_imp_DDDPM();
  }

  /* End of Chart: '<S1>/DDDPM' */
}

/* Model initialize function */
void YixuanMeng_SL_imp_initialize(void)
{
  /* Registration code */

  /* initialize error status */
  rtmSetErrorStatus(YixuanMeng_SL_imp_M, (NULL));

  /* states (dwork) */
  (void) memset((void *)&YixuanMeng_SL_imp_DW, 0,
                sizeof(DW_YixuanMeng_SL_imp_T));

  /* SystemInitialize for Chart: '<S1>/DDDPM' */
  YixuanMeng_SL_imp_DW.is_AVI = YixuanMeng_S_IN_NO_ACTIVE_CHILD;
  YixuanMeng_SL_imp_DW.is_LRI = YixuanMeng_S_IN_NO_ACTIVE_CHILD;
  YixuanMeng_SL_imp_DW.is_PVARP = YixuanMeng_S_IN_NO_ACTIVE_CHILD;
  YixuanMeng_SL_imp_DW.is_URI = YixuanMeng_S_IN_NO_ACTIVE_CHILD;
  YixuanMeng_SL_imp_DW.is_VRP = YixuanMeng_S_IN_NO_ACTIVE_CHILD;
  YixuanMeng_SL_imp_DW.is_active_c1_YixuanMeng_SL_imp = 0U;
}

/* Model terminate function */
void YixuanMeng_SL_imp_terminate(void)
{
  /* (no terminate code required) */
}
