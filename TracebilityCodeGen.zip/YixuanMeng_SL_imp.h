/*
 * YixuanMeng_SL_imp.h
 *
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Code generation for model "YixuanMeng_SL_imp".
 *
 * Model version              : 1.296
 * Simulink Coder version : 9.2 (R2019b) 18-Jul-2019
 * C source code generated on : Fri Dec 27 14:26:13 2019
 *
 * Target selection: ert.tlc
 * Note: GRT includes extra infrastructure and instrumentation for prototyping
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef RTW_HEADER_YixuanMeng_SL_imp_h_
#define RTW_HEADER_YixuanMeng_SL_imp_h_
#include <stddef.h>
#include <string.h>
#ifndef YixuanMeng_SL_imp_COMMON_INCLUDES_
# define YixuanMeng_SL_imp_COMMON_INCLUDES_
#include "rtwtypes.h"
#include "rtw_continuous.h"
#include "rtw_solver.h"
#endif                                 /* YixuanMeng_SL_imp_COMMON_INCLUDES_ */

#include "YixuanMeng_SL_imp_types.h"

/* Shared type includes */
#include "multiword_types.h"
#include "MW_target_hardware_resources.h"

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
# define rtmGetErrorStatus(rtm)        ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
# define rtmSetErrorStatus(rtm, val)   ((rtm)->errorStatus = (val))
#endif

/* Block states (default storage) for system '<Root>' */
typedef struct {
  real_T APLRI;                        /* '<S1>/DDDPM' */
  uint16_T tmpVRP;                     /* '<S1>/DDDPM' */
  uint16_T tmpPVARP;                   /* '<S1>/DDDPM' */
  uint16_T tmpAVI;                     /* '<S1>/DDDPM' */
  uint16_T tmpLRI;                     /* '<S1>/DDDPM' */
  uint16_T tmpURI;                     /* '<S1>/DDDPM' */
  uint8_T is_active_c1_YixuanMeng_SL_imp;/* '<S1>/DDDPM' */
  uint8_T is_AVI;                      /* '<S1>/DDDPM' */
  uint8_T is_URI;                      /* '<S1>/DDDPM' */
  uint8_T is_PVARP;                    /* '<S1>/DDDPM' */
  uint8_T is_LRI;                      /* '<S1>/DDDPM' */
  uint8_T is_VRP;                      /* '<S1>/DDDPM' */
  boolean_T VS;                        /* '<S1>/DDDPM' */
  boolean_T AS;                        /* '<S1>/DDDPM' */
  boolean_T enterURI;                  /* '<S1>/DDDPM' */
  boolean_T VP1;                       /* '<S1>/DDDPM' */
  boolean_T AP1;                       /* '<S1>/DDDPM' */
} DW_YixuanMeng_SL_imp_T;

/* Parameters (default storage) */
struct P_YixuanMeng_SL_imp_T_ {
  real_T AEI_Value;                    /* Expression: 500
                                        * Referenced by: '<S1>/AEI'
                                        */
  uint16_T AVI_Value;                  /* Computed Parameter: AVI_Value
                                        * Referenced by: '<S1>/AVI'
                                        */
  uint16_T VRP_Value;                  /* Computed Parameter: VRP_Value
                                        * Referenced by: '<S1>/VRP'
                                        */
  uint16_T TPVARP_Value;               /* Computed Parameter: TPVARP_Value
                                        * Referenced by: '<S1>/TPVARP'
                                        */
  uint16_T LRI_Value;                  /* Computed Parameter: LRI_Value
                                        * Referenced by: '<S1>/LRI'
                                        */
  uint16_T URI_Value;                  /* Computed Parameter: URI_Value
                                        * Referenced by: '<S1>/URI'
                                        */
};

/* Real-time Model Data Structure */
struct tag_RTM_YixuanMeng_SL_imp_T {
  const char_T *errorStatus;
};

/* Block parameters (default storage) */
extern P_YixuanMeng_SL_imp_T YixuanMeng_SL_imp_P;

/* Block states (default storage) */
extern DW_YixuanMeng_SL_imp_T YixuanMeng_SL_imp_DW;

/* Model entry point functions */
extern void YixuanMeng_SL_imp_initialize(void);
extern void YixuanMeng_SL_imp_step(void);
extern void YixuanMeng_SL_imp_terminate(void);

/* Real-time Model object */
extern RT_MODEL_YixuanMeng_SL_imp_T *const YixuanMeng_SL_imp_M;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'YixuanMeng_SL_imp'
 * '<S1>'   : 'YixuanMeng_SL_imp/DDD pacemaker1'
 * '<S2>'   : 'YixuanMeng_SL_imp/DDD pacemaker1/DDDPM'
 */
#endif                                 /* RTW_HEADER_YixuanMeng_SL_imp_h_ */
